package com.carlca.twisterella.twister

class KnobMidiInfo(
    val encoder: MidiInfo,
    val button: MidiInfo,
    val rgbLight: LightMidiInfo,
    val ringLight: LightMidiInfo
)
